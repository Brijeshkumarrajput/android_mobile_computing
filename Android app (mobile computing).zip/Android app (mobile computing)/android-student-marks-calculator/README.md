
### Student list:

![Student List](/screenshots/studentList.png)


### Info dialog:

![Info Dialog](/screenshots/help.png)


### Adding a new student:

![Add Student](/screenshots/addStudent.png)


### A student's marks:

![Student Marks](/screenshots/studentMarks.png)


### Summary of all student marks:

![Marks Summary](/screenshots/marksSummary.png)